Overview of software:

Flash Drive Leveling is a software that realize long-life and high-speed for a flash drive.

In general, there is a life for flash memory (such as SD card or USB flash drive). In addition, random write is slow. By optimizing data placement when writing to the flash memory, "Flash Drive Leveling" mitigates these disadvantages.

Cost down of flash memory is underway. You can use a USB flash drive as a substitute for an external disk. In such cases, "Flash Drive Leveling" is recommended.


Contact to the author:

rtrdprgrmr@yahoo.co.jp


License:

BSD (Please refer to license.rtf)


Requirements:

32-bit version of WindowsXP or later


How to install:

Please run fdlvling_en.msi


How to uninstall:

Please uninstall from "Add or Remove Programs" or " Programs and Features" in the Control Panel.


Online Documentation:

http://fdlvlingen.blogspot.jp


Configuration:

The step by step procedure to start leveling after installing the software.

1. Connect USB flash drive of 1G bytes or more which may erase the data.

2. Select the drive in Windows Explorer, the menu is displayed on the right-click, and then run the "Leveling". Setting panel of leveling will appear .

3. Check "Enable Leveling".

4. After setting virtual size and other configurations, click Apply.

5. Warning screen to erase the data will appear. Data is erased when you click [OK], and leveling will be enabled.

6. After a while, the screen of the Windows format will appear automatically.  Format it with a file system of your choice.
(If that does not appear , double-click the drive, or select the format on the right-click menu)

7. Now, leveling is enabled. You can use it in the same way as conventional flash drive. Please check the operation.

8. When removing the flash drive from the computer, before removing, please run "Eject" from the right-click menu on the drive.

9. You do not need to do the setting again. The setting is automatically recognized when you connect it to the computer.

Tip 1: Data can not be read by other equipment nor computers which Flash Drive Leveling is not installed.

Tip 2: To stop leveling of flash drive,  uncheck "Enable Leveling" in the setting panel of leveling.

Please refer to the online documentation for more explanation, such as how it works.